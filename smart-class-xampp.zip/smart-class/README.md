# Smart Class Assistance (XAMPP version: PHP + MySQL)

## Set up
1. Install XAMPP and open the **XAMPP Control Panel**. Click **Start** next to **Apache** and **MySQL**.
2. Copy this whole `smart-class` folder into `C:\xampp\htdocs\` (Mac: `/Applications/XAMPP/htdocs/`).
3. Open **http://localhost/smart-class/** in your browser.

The first visit creates the database `smart_class` and all its tables automatically.
Look at the data any time at **http://localhost/phpmyadmin**.

## Settings (`config.php`)
- `STAFF_CODE`: the code staff enter to register. Change it before real use.
- `DB_PASS`: XAMPP's MySQL password is empty by default. If you set one, put it here.

## Backup
Export the `smart_class` database from phpMyAdmin (Export → Go) **and** copy the `uploads` folder.

## Notes
- Allowed uploads: PDF, Word, PowerPoint, TXT, images and videos (mp4, webm, mov, mkv, avi, 3gp). Limit 500 MB, set in `.htaccess`.
- If a big upload fails, also set `upload_max_filesize` and `post_max_size` in `C:\xampp\php\php.ini`, then restart Apache.
- Staff and student accounts from the old Node version are not copied over. Register again.
