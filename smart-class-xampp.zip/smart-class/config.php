<?php
// ✏️ Settings for XAMPP. The defaults below work on a fresh XAMPP install.
const DB_HOST = 'localhost';
const DB_USER = 'root';
const DB_PASS = '';              // XAMPP's MySQL root password is empty by default
const DB_NAME = 'smart_class';   // created automatically on first run
const STAFF_CODE = 'STAFF2026';  // staff must enter this to register: CHANGE IT
const UPLOAD_DIR = __DIR__ . '/uploads';
