<?php
require __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
mysqli_report(MYSQLI_REPORT_OFF);

function out($d, $c = 200) { http_response_code($c); echo json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit; }
function fail($c, $m) { out(['error' => $m], $c); }
function uid() { return bin2hex(random_bytes(8)); }
function now() { return gmdate('Y-m-d H:i:s'); }
function iso($s) { return str_replace(' ', 'T', $s) . 'Z'; }
function body() {
    static $b = null;
    if ($b === null) { $b = json_decode(file_get_contents('php://input'), true); if (!is_array($b)) $b = []; }
    return $b;
}

// ---------- Database (created automatically on first run) ----------
function db() {
    static $pdo = null;
    if ($pdo) return $pdo;
    try {
        $pdo = new PDO('mysql:host=' . DB_HOST . ';charset=utf8mb4', DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
    } catch (PDOException $e) {
        fail(500, 'Cannot connect to MySQL. Start MySQL in the XAMPP Control Panel and check config.php.');
    }
    $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $pdo->exec('USE `' . DB_NAME . '`');
    if (!$pdo->query("SHOW TABLES LIKE 'users'")->fetch()) {
        $t = 'n INT AUTO_INCREMENT PRIMARY KEY, id CHAR(16) NOT NULL UNIQUE,';
        $e = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4';
        foreach ([
            "CREATE TABLE users ($t name VARCHAR(100) NOT NULL, email VARCHAR(190) NOT NULL UNIQUE, role ENUM('student','staff') NOT NULL, password_hash VARCHAR(255) NOT NULL, created_at DATETIME NOT NULL) $e",
            "CREATE TABLE sessions (token CHAR(48) PRIMARY KEY, user_id CHAR(16) NOT NULL, created_at DATETIME NOT NULL, INDEX(user_id)) $e",
            "CREATE TABLE courses ($t name VARCHAR(120) NOT NULL UNIQUE) $e",
            "CREATE TABLE materials ($t title VARCHAR(200) NOT NULL, course_id CHAR(16) NOT NULL, subject VARCHAR(120) NOT NULL, description TEXT, file VARCHAR(80) NOT NULL, original VARCHAR(255) NOT NULL, type ENUM('video','document') NOT NULL, by_name VARCHAR(100) NOT NULL, by_id CHAR(16) NOT NULL, created_at DATETIME NOT NULL, INDEX(course_id)) $e",
            "CREATE TABLE quizzes ($t title VARCHAR(200) NOT NULL, course_id CHAR(16) NOT NULL, subject VARCHAR(120) NOT NULL, questions MEDIUMTEXT NOT NULL, by_name VARCHAR(100) NOT NULL, created_at DATETIME NOT NULL, INDEX(course_id)) $e",
            "CREATE TABLE results ($t quiz_id CHAR(16) NOT NULL, quiz VARCHAR(200) NOT NULL, student_id CHAR(16) NOT NULL, student VARCHAR(100) NOT NULL, score INT NOT NULL, total INT NOT NULL, created_at DATETIME NOT NULL, INDEX(student_id)) $e",
            "CREATE TABLE messages ($t name VARCHAR(100) NOT NULL, email VARCHAR(120) NOT NULL, message TEXT NOT NULL, created_at DATETIME NOT NULL) $e",
        ] as $sql) $pdo->exec($sql);
    }
    return $pdo;
}
function q($sql, $p = []) { $s = db()->prepare($sql); $s->execute($p); return $s; }

// ---------- Auth ----------
function auth($role = null) {
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if (!$h && function_exists('getallheaders')) foreach (getallheaders() as $k => $v) if (strtolower($k) === 'authorization') $h = $v;
    $t = trim(preg_replace('/^Bearer\s+/i', '', $h));
    $u = $t ? q('SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token = ? AND s.created_at > (UTC_TIMESTAMP() - INTERVAL 30 DAY)', [$t])->fetch() : false;
    if (!$u) fail(401, 'Please log in');
    if ($role && $u['role'] !== $role) fail(403, 'Not allowed');
    $u['token'] = $t;
    return $u;
}

// ---------- Row formatting (same JSON shape the page already expects) ----------
function mat($r) {
    return ['id' => $r['id'], 'title' => $r['title'], 'courseId' => $r['course_id'], 'subject' => $r['subject'],
        'description' => $r['description'] ?? '', 'file' => $r['file'], 'original' => $r['original'], 'type' => $r['type'],
        'by' => $r['by_name'], 'byId' => $r['by_id'], 'date' => iso($r['created_at'])];
}
function quiz($r, $staff) {
    $qs = json_decode($r['questions'], true) ?: [];
    if (!$staff) $qs = array_map(fn($x) => ['q' => $x['q'], 'options' => $x['options']], $qs);
    return ['id' => $r['id'], 'title' => $r['title'], 'courseId' => $r['course_id'], 'subject' => $r['subject'],
        'questions' => $qs, 'by' => $r['by_name'], 'date' => iso($r['created_at'])];
}
function course($id) { return q('SELECT * FROM courses WHERE id = ?', [(string)$id])->fetch(); }

// ---------- Routing: api.php/<resource>/<id>/<action> ----------
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$i = strpos($path, 'api.php');
if ($i === false) fail(404, 'Not found');
$seg = array_values(array_filter(explode('/', substr($path, $i + 7)), 'strlen'));
$res = $seg[0] ?? ''; $id = $seg[1] ?? null; $act = $seg[2] ?? null;
$key = $method . ' ' . $res . ($id !== null ? '/id' : '') . ($act ? '/' . $act : '');

try {
switch ($key) {

case 'POST register': {
    $b = body();
    $name = trim($b['name'] ?? ''); $email = strtolower(trim($b['email'] ?? '')); $pw = (string)($b['password'] ?? ''); $role = $b['role'] ?? '';
    if (!$name || !$email || strlen($pw) < 6) fail(400, 'Fill all fields (password min 6 characters)');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail(400, 'Enter a valid email address');
    if (!in_array($role, ['student', 'staff'], true)) fail(400, 'Invalid role');
    if ($role === 'staff' && !hash_equals(STAFF_CODE, (string)($b['code'] ?? ''))) fail(403, 'Wrong staff access code');
    if (q('SELECT 1 FROM users WHERE email = ?', [$email])->fetch()) fail(409, 'Email already registered');
    q('INSERT INTO users (id, name, email, role, password_hash, created_at) VALUES (?,?,?,?,?,?)',
        [uid(), mb_substr($name, 0, 100), $email, $role, password_hash($pw, PASSWORD_DEFAULT), now()]);
    out(['ok' => true]);
}
case 'POST login': {
    $b = body();
    $u = q('SELECT * FROM users WHERE email = ? AND role = ?', [strtolower(trim($b['email'] ?? '')), $b['role'] ?? ''])->fetch();
    if (!$u || !password_verify((string)($b['password'] ?? ''), $u['password_hash'])) fail(401, 'Invalid email or password');
    $token = bin2hex(random_bytes(24));
    q('DELETE FROM sessions WHERE created_at < (UTC_TIMESTAMP() - INTERVAL 30 DAY)');
    q('INSERT INTO sessions (token, user_id, created_at) VALUES (?,?,?)', [$token, $u['id'], now()]);
    out(['token' => $token, 'user' => ['name' => $u['name'], 'role' => $u['role']]]);
}
case 'POST logout': {
    $u = auth(); q('DELETE FROM sessions WHERE token = ?', [$u['token']]); out(['ok' => true]);
}

case 'GET public': {
    $n = fn($sql) => (int)q($sql)->fetchColumn();
    $cs = q('SELECT c.id, c.name, (SELECT COUNT(*) FROM materials m WHERE m.course_id = c.id) AS materials, (SELECT COUNT(*) FROM quizzes z WHERE z.course_id = c.id) AS quizzes FROM courses c ORDER BY c.n')->fetchAll();
    foreach ($cs as &$c) { $c['materials'] = (int)$c['materials']; $c['quizzes'] = (int)$c['quizzes']; }
    out(['stats' => ['courses' => $n('SELECT COUNT(*) FROM courses'), 'materials' => $n('SELECT COUNT(*) FROM materials'),
        'videos' => $n("SELECT COUNT(*) FROM materials WHERE type = 'video'"), 'students' => $n("SELECT COUNT(*) FROM users WHERE role = 'student'")], 'courses' => $cs]);
}
case 'POST contact': {
    $b = body(); $name = trim($b['name'] ?? ''); $email = trim($b['email'] ?? ''); $msg = trim($b['message'] ?? '');
    if (!$name || !$email || !$msg) fail(400, 'Please fill in all fields');
    q('INSERT INTO messages (id, name, email, message, created_at) VALUES (?,?,?,?,?)',
        [uid(), mb_substr($name, 0, 100), mb_substr($email, 0, 120), mb_substr($msg, 0, 2000), now()]);
    out(['ok' => true]);
}
case 'GET messages': {
    auth('staff');
    out(array_map(fn($r) => ['id' => $r['id'], 'name' => $r['name'], 'email' => $r['email'], 'message' => $r['message'], 'date' => iso($r['created_at'])],
        q('SELECT * FROM messages ORDER BY n DESC')->fetchAll()));
}

case 'GET courses': { auth(); out(q('SELECT id, name FROM courses ORDER BY n')->fetchAll()); }
case 'POST courses': {
    auth('staff'); $name = trim(body()['name'] ?? '');
    if (!$name) fail(400, 'Enter a course name');
    if (q('SELECT 1 FROM courses WHERE name = ?', [$name])->fetch()) fail(409, 'Course already exists');
    q('INSERT INTO courses (id, name) VALUES (?,?)', [uid(), mb_substr($name, 0, 120)]); out(['ok' => true]);
}
case 'DELETE courses/id': {
    auth('staff');
    if (q('SELECT 1 FROM materials WHERE course_id = ? UNION SELECT 1 FROM quizzes WHERE course_id = ?', [$id, $id])->fetch())
        fail(400, "Delete this course's materials and quizzes first");
    q('DELETE FROM courses WHERE id = ?', [$id]); out(['ok' => true]);
}

case 'GET materials': { auth(); out(array_map('mat', q('SELECT * FROM materials ORDER BY n DESC')->fetchAll())); }
case 'POST materials': {
    $u = auth('staff');
    if (empty($_POST) && empty($_FILES) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0)
        fail(413, 'File is too large for the server. Raise upload_max_filesize and post_max_size in php.ini (see README).');
    $f = $_FILES['file'] ?? null; $title = trim($_POST['title'] ?? ''); $c = course($_POST['courseId'] ?? '');
    if ($f && in_array($f['error'], [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true))
        fail(413, 'File is too large for the server. Raise upload_max_filesize and post_max_size in php.ini (see README).');
    if (!$f || $f['error'] !== UPLOAD_ERR_OK || !$title || !$c) fail(400, 'Choose a course, enter a title and select a file');
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    $video = ['mp4', 'webm', 'mov', 'mkv', 'avi', '3gp', 'm4v'];
    $docs = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'txt', 'png', 'jpg', 'jpeg', 'gif', 'webp'];
    if (!in_array($ext, array_merge($video, $docs), true)) fail(400, 'Unsupported file type. Allowed: PDF, Word, PowerPoint, TXT, images and videos.');
    if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0775, true);
    $stored = uid() . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], UPLOAD_DIR . '/' . $stored)) fail(500, 'Could not save the file. Check that the uploads folder is writable.');
    $mid = uid(); $type = in_array($ext, $video, true) ? 'video' : 'document';
    q('INSERT INTO materials (id, title, course_id, subject, description, file, original, type, by_name, by_id, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
        [$mid, mb_substr($title, 0, 200), $c['id'], $c['name'], mb_substr($_POST['description'] ?? '', 0, 2000), $stored, mb_substr(basename($f['name']), 0, 255), $type, $u['name'], $u['id'], now()]);
    out(mat(q('SELECT * FROM materials WHERE id = ?', [$mid])->fetch()));
}
case 'DELETE materials/id': {
    auth('staff'); $m = q('SELECT * FROM materials WHERE id = ?', [$id])->fetch();
    if (!$m) fail(404, 'Not found');
    @unlink(UPLOAD_DIR . '/' . basename($m['file']));
    q('DELETE FROM materials WHERE id = ?', [$id]); out(['ok' => true]);
}

case 'GET quizzes': {
    $u = auth(); $staff = $u['role'] === 'staff';
    out(array_map(fn($r) => quiz($r, $staff), q('SELECT * FROM quizzes ORDER BY n DESC')->fetchAll()));
}
case 'POST quizzes': {
    $u = auth('staff'); $b = body(); $c = course($b['courseId'] ?? ''); $title = trim($b['title'] ?? ''); $qs = $b['questions'] ?? null;
    if (!$c || !$title || !is_array($qs) || !$qs) fail(400, 'Choose a course, enter a title and add at least one question');
    $clean = [];
    foreach ($qs as $x) {
        if (!is_array($x) || !isset($x['q'], $x['options'], $x['answer']) || !is_array($x['options']) || count($x['options']) !== 4 || !in_array($x['answer'], [0, 1, 2, 3], true))
            fail(400, 'Each question needs 4 options and a correct answer');
        $clean[] = ['q' => (string)$x['q'], 'options' => array_map('strval', array_values($x['options'])), 'answer' => (int)$x['answer']];
    }
    q('INSERT INTO quizzes (id, title, course_id, subject, questions, by_name, created_at) VALUES (?,?,?,?,?,?,?)',
        [uid(), mb_substr($title, 0, 200), $c['id'], $c['name'], json_encode($clean, JSON_UNESCAPED_UNICODE), $u['name'], now()]);
    out(['ok' => true]);
}
case 'DELETE quizzes/id': { auth('staff'); q('DELETE FROM quizzes WHERE id = ?', [$id]); out(['ok' => true]); }
case 'POST quizzes/id/submit': {
    $u = auth('student'); $z = q('SELECT * FROM quizzes WHERE id = ?', [$id])->fetch();
    if (!$z) fail(404, 'Quiz not found');
    $qs = json_decode($z['questions'], true) ?: []; $ans = body()['answers'] ?? []; $score = 0;
    foreach ($qs as $k => $x) if (isset($ans[$k]) && $ans[$k] === $x['answer']) $score++;
    q('INSERT INTO results (id, quiz_id, quiz, student_id, student, score, total, created_at) VALUES (?,?,?,?,?,?,?,?)',
        [uid(), $z['id'], $z['title'], $u['id'], $u['name'], $score, count($qs), now()]);
    out(['score' => $score, 'total' => count($qs), 'correct' => array_column($qs, 'answer')]);
}

case 'GET results': {
    $u = auth();
    $rows = $u['role'] === 'staff' ? q('SELECT * FROM results ORDER BY n DESC')->fetchAll()
        : q('SELECT * FROM results WHERE student_id = ? ORDER BY n DESC', [$u['id']])->fetchAll();
    out(array_map(fn($r) => ['id' => $r['id'], 'quizId' => $r['quiz_id'], 'quiz' => $r['quiz'], 'studentId' => $r['student_id'], 'student' => $r['student'],
        'score' => (int)$r['score'], 'total' => (int)$r['total'], 'date' => iso($r['created_at'])], $rows));
}

default: fail(404, 'Not found');
}
} catch (PDOException $e) {
    fail(500, 'Database error. Check that MySQL is running and config.php is correct.');
}
